<?php
namespace App\Http\Controllers;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller {
    public function login() {
        if (session('ID') != null)
           return redirect('home');
        else 
            return view('login');
        }

    public function postLogin() {
        $request = request();
        if(!empty($request)){
            $user = User::where('ID',request('ID'))->where('password', request('password'))->first();
            if ($user){
                Session::put('ID',$user->ID);
                return redirect('profile');
            }
            else{
                return redirect('login')->withInput();
            }
        }
        else 
            return redirect('login');
    }

    public function logout(){

        Session::flush();
        return redirect('login');
    }
}
?>