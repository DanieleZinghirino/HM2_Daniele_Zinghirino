<?php
namespace App\Http\Controllers;
use Illuminate\Routing\Controller;
use App\Models\User;
use App\Models\PT;
use App\Models\Card;
use App\Models\Subscription;
use App\Models\Training;
use App\Models\Comment;
use App\Models\Course;
use App\Models\CourseUser;
use Illuminate\Support\Facades\Session;
use DateTime;

class RegisterController extends Controller {

    public function index() {
        return view('register');
    } 

    public function register() {
        $form = request();

        $anno = $form['anno_nascita'];
        $mese = $form['mese_nascita'];
        $giorno = $form['giorno_nascita'];
        $data = "$anno-$mese-$giorno";

        $data_nascita = new DateTime("$giorno.$mese.$anno");
        $data_oggi = new DateTime('00:00:00');
        $diff = $data_oggi->diff($data_nascita);
        $eta = ($diff->y);

        if($this->countErrors($form) === 0 ){
            $user = User::create([
                'ID' => $form['ID'],
                'name' => $form['name'],
                'surname' => $form['surname'],
                'password' => $form['password'],
                'birth' => $data,
                'age' => $eta,  
            ]);
            if ($user) {
                Session::put('ID', $user->ID);
                return redirect('registerSub');
            } 
            else {
                return redirect('register')->withInput();
            }
        }
        else 
            return redirect('register')->withInput();
    }
    
    private function countErrors($data) {
        $error = array();
        
        if (strlen($data["password"]) < 8) {
            $error[] = "Caratteri password insufficienti";
        } 
        
        if (strcmp($data["password"], $data["confirm_password"]) != 0) {
            $error[] = "Le password non coincidono";
        }
       
        if (checkdate($data['mese_nascita'],$data['giorno_nascita'],$data['anno_nascita'])==false){
            $error[] = "Data non valida";
        }
       
        if (empty($data["name"]) && empty($data["surname"]) && empty($data["ID"]) && empty($data["giorno_nascita"]) && 
        empty($_POST["mese_nascita"]) && empty($_POST["anno_nascita"]) && empty($data["password"]) && empty($data["confirm_password"])){
            $error[] = "Campi non compilati";
        }
  
        return count($error);
    }


    public function checkID($ID) {
        $exist = User::where('ID', $ID)->exists();
        return ['exists' => $exist];
    }

    public function registerSub(){
        if (session('ID') != null){
            $pts = Pt::all()->toArray();
            $cards = Card::all()->toArray();
            return view('registerSub')->with('pts',$pts)->with('cards',$cards);}

        else 
            return redirect('register');

    }

    public function registerSubPost(){
        $data = request();
        $price = 0;
        if($data["subscription"] == 1){
            $price = 45;
            $date_out = strtotime('+1 month', strtotime(date ("Y/m/d")));
            $date_out = date ('Y/m/d', $date_out);}
        elseif($data["subscription"] == 3){
            $price = 120;
            $date_out = strtotime('+3 month', strtotime(date ("Y/m/d")));
            $date_out = date ('Y/m/d', $date_out);}
        elseif($data["subscription"] == 6){
            $price = 210;
            $date_out = strtotime('+3 month', strtotime(date ("Y/m/d")));
            $date_out = date ('Y/m/d', $date_out);}
        elseif($data["subscription"] == 12){
            $price = 330;
            $date_out = strtotime('+1 year', strtotime(date ("Y/m/d")));
            $date_out = date ('Y/m/d', $date_out);}
        if(!empty($data["subscription"]) && !empty($data["pt"] && !empty($data["card"]))){
            $user_id = Session::get("ID");

            $old_sub = Subscription::where('user_id',$user_id)->first();

            
            if($old_sub){
                $delete = Subscription::where('user_id',$user_id)->delete();
            }
            $sub = Subscription::create([
                'user_id' => Session::get("ID"),
                'gym_id' => 1,
                'price' => $price,
                'duration' => $data["subscription"],
                'date_in' => date ("Y/m/d"),  
                'date_out' => $date_out,
            ]);

            $training = Training::create([
                'user_id' => Session::get("ID"),
                'card_id' => $data["card"],
                'pt_id' => $data["pt"],

            ]);

            return redirect('profile');}
        else 
            return redirect('registerSub');
    }

    public function addComment(){    
    if (session('ID') != null)
        return view("add_comment");
    else 
        return redirect ('login');
    }


    public function addCommentPost(){   

    $request = request();
    
    $text = $request["recensione"];
    $user = User::find(Session::get("ID"));
    $day = date ("Y/m/d");
    $time = date("H:i");  
    if(!empty($request)){
        $comment = Comment::create([
            'text' => $text,
            'user_id' => $user->ID,
            'day' => $day,
            'time' => $time,
        ]);
        return redirect('comment');}
    else
        return redirect('addComment');
    }

    public function changePt(){
        $pts = Pt::all();
        $user = User::find(Session::get("ID"));
        $training = Training::where('user_id',$user->ID)->first();
        $pt_user = $training->pt_id;
        if (session('ID') != null)
            return view("change_pt")->with('pts',$pts)->with('pt_user',$pt_user);
        else
            return redirect('login');
        
    }

    public function changePtPost(){
        $request = request();

    if (!empty($request["pt"])){
        $user = User::find(Session::get("ID"));
        $pt=$request["pt"];
        $old_training = $training = Training::where('user_id',$user->ID)->first();
        $destroy = Training::where('user_id',$user->ID)->delete();
        
        $training = Training::create([
            'user_id' => Session::get("ID"),
            'card_id' => $old_training->card_id,
            'pt_id' => $pt,   
            ]);
        return redirect('profile');}
        
       
    else
        return redirect('changePt');
    }

    
    public function deleteCourse(){
        $user = User::find(Session::get('ID'));
        $courses_user = CourseUser::where('user_id',$user->ID)->get();
        foreach($courses_user as $course_user){
            $courses[] = Course::where('ID',$course_user["course_id"])->get()->toArray();
            }
        if (session('ID') != null)
            return view('delete_course')->with('courses',$courses); 
        else   
            return redirect('login');}


    public function deleteCoursePost(){
        $request = request();
        $ID=$request["corso"];
        if (!empty($ID)){
            $user = User::find(Session::get('ID'));;
            $delete = CourseUser::where('user_id',$user->ID)->where('course_id',$ID)->delete();
           return redirect('profile'); 
        }
        else 
            return redirect('deleteCourse');
        }

    public function addCourse(){
        $user = User::find(Session::get('ID'));
        $id_courses_user =  CourseUser::where('user_id',$user->ID)->get('course_id')->toArray();
        $courses = Course::select('*')->whereNotIn('ID',$id_courses_user)->get();
        $dim = count($courses);

        foreach($courses as $course){
        $users = CourseUser::where('course_id',$course["ID"])->get();
        $numbers[]=(count($users));}
        
        if (session('ID') != null)
            return view('add_course')->with('courses',$courses)->with('numbers',$numbers)->with('dim',$dim)->with('i',0); 
        else
            return redirect('login');
    }


    public function addCoursePost(){
        $request = request();
        $ID=$request["corso"];
        if (!empty($ID)){
            $course_user = CourseUser::create([
                'user_id' =>  User::find(Session::get('ID'))->ID,
                'course_id' => $ID]);
           return redirect('profile'); 
        }
        else 
            return redirect('addCourse');}

}
