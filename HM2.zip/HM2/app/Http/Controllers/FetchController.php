<?php
namespace App\Http\Controllers;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use App\Models\User;
use App\Models\PT;
use App\Models\Card;
use App\Models\Subscription;
use App\Models\Training;
use App\Models\Comment;
use App\Models\Course;
use App\Models\Office;
use App\Models\Director;
use App\Models\CourseUser;
use Illuminate\Support\Facades\Session;

class FetchController extends Controller {
   

    public function fetchData(){
        $user = User::find(Session::get("ID"));

        return response()->json([
            'ID' => $user->ID,
            'name' => $user->name,
            'surname' => $user->surname,
            'birth' => $user->birth,
            'age' => $user->age,
        ]);
    }


    public function fetchSubscription(){
        $user = User::find(Session::get("ID"));

        $subscription = Subscription::where('user_id',$user->ID)->first();
        //$subscription = $user->subscription()->get();
        if($subscription){
        return response()->json([
            'ID' => $user->ID,
            'price' => $subscription->price,
            'duration' => $subscription->duration,
            'date_in' => $subscription->date_in,
            'date_out' => $subscription->date_out,
        ]);}
        else 
        return response()->json([
            'ID' => 0
        ]);
    }

    public function fetchTraining(){
        $user = User::find(Session::get("ID"));

        $training = Training::where('user_id',$user->ID)->first();

        $card = Card::find($training->card_id);
        $pt = Pt::find($training->pt_id);
        //$subscription = $user->subscription()->get();
        if($training){
        return response()->json([
            'ID' => $training->ID,
            'type' => $card->type,
            'duration' => $card->duration,
            'difficulty' => $card->difficulty,
            'pt_name' => $pt->name,
            'pt_surname' => $pt->surname
        ]);}
        else 
        return response()->json([
            'ID' => 0
        ]);
    }

    public function fetchPt(){
        $user = User::find(Session::get("ID"));

        $training = Training::where('user_id',$user->ID)->first();

        $pt = Pt::find($training->pt_id);

        if($pt){
        return response()->json([
            'ID' => $pt->ID,
            'name' => $pt->name,
            'surname' => $pt->surname,
            'birth' => $pt->birth,
        ]);}
        else 
        return response()->json([
            'ID' => 0
        ]);
    }

    public function fetchCourse(){
        $user = User::find(Session::get("ID"));

        $courses_user = CourseUser::where('user_id',$user->ID)->get()->toArray();
        
        if($courses_user){
            foreach($courses_user as $course_user){
                $course = Course::find($course_user["course_id"]);
                $json[]=array(
                    'ID' => $course["ID"],
                    'name' => $course["name"],
                    'time' => $course["time"],
                    'day' => $course["day"],
                    'image' =>$course["image"],
                    'description' =>$course["description"],
                );
            }
            return response()->json($json);
        }
            else 
            return response()->json([
                'ID' => 0
            ]);
        
       
    }

    public function fetchCourses(){
        $courses = Course::get()->toArray();
        foreach($courses as $course){
            $json[]=array(
                'ID' => $course["ID"],
                'name' => $course["name"],
                'time' => $course["time"],
                'day' => $course["day"],
                'image' => $course["image"],
                'description' => $course["description"],
            );}
        return response()->json($json);
       
    }

    public function fetchComment(){
        $comments = Comment::get()->toArray();
        if($comments){
            foreach($comments as $comment){
                $user = User::find($comment["user_id"]);
                $json[]=array(
                    'ID' => $comment["ID"],
                    'text' => $comment["text"],
                    'name' => $user["name"],
                    'surname' => $user["surname"],
                    'day' => $comment["day"],
                    'time' => $comment["time"],
                );
            }
            return response()->json($json);
        }
            else 
            return response()->json([
                'ID' => 0
            ]);
    }

    public function fetchOffice(){
        $offices = Office::get()->toArray();
        foreach($offices as $office){
            $director = Director::find($office["director_id"]);
            $json[]=array(
                'ID' => $office["ID"],
                'gym_id' => 1,
                'city' => $office["city"],
                'address' => $office["address"],
                'director_name' => $director["name"],
                'director_surname' => $director["surname"],
            );}
        return response()->json($json);
       
    }

    public function fetchPts(){
        $pts = Pt::get()->toArray();
        foreach($pts as $pt){
            $json[]=array(
                'ID' => $pt["ID"],
                'name' => $pt["name"],
                'surname' => $pt["surname"],
                'birth' => $pt["birth"],
            );}
        return response()->json($json);
       
    }

    public function fetchTimetables(){
        
    $year = date("Y");
    $month = date('m');
    $day = date('d');

    $url='https://holidays.abstractapi.com/v1/?api_key='.env('API_KEY').'&country=It&year='.$year.'&month='.$month.'&day='.$day;

    $json=Http::get($url);

    $response = json_decode($json, true);

    if ($response==!null) 
        return response()->json(['ok' => 1]);

    else 
        return response()->json(['ok' => 0]);
        }

    }
