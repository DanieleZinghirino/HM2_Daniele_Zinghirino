<?php
namespace App\Http\Controllers;
use App\Models\Course;
use Illuminate\Routing\Controller;

class HomeController extends Controller {
    public function home() {
        if (session('ID') != null)
            return view('home')->with('session',1);
        else
        return view('home')->with('session',0);
    }
    
    public function profile(){
        return view('profile');
    }

    public function data(){
        if (session('ID') != null)
            return view('data_user');
        else 
            return redirect('login');
    }

    public function subscription(){
        if (session('ID') != null)
            return view('data_subscription');
        else 
            return redirect('login');
    }

    public function training(){
        if (session('ID') != null)
            return view('data_training');
        else 
            return redirect('login');
    }

    public function pt(){
        if (session('ID') != null)
            return view('data_pt');
        else 
            return redirect('login');
    }
    
    public function course(){
        if (session('ID') != null)
            return view('data_course');
        else 
            return redirect('login');
    }

    public function comment(){    
            return view('data_comment');
    }

    public function courses(){
        $courses = Course::all();
        return view('courses')->with('courses',$courses);
    }

    public function office(){
        return view('office');
    }

    public function pts(){
        return view('pts');
    }

    public function exercise(){
        return view('exercise');
    }

    public function timetables(){
        return view('timetables');
    }
    
}
?>