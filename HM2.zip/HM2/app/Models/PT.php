<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pt extends Model {
    protected $fillable = [
        'gym_id', 'ID', 'name', 'surname', 'birth'
    ];

    public $timestamps=false;

    public function palestra() {
        return $this->belongsTo("App\Models\Palestra");
    }
    
    public function training(){
        return $this->hasMany('App\Models\Training');
    }

}


?>