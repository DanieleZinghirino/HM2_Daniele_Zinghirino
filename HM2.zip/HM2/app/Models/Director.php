<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Director extends Model {
    protected $fillable = [
        'ID', 'name', 'surname', 'birth'
    ];
    public $timestamps=false;

    public function Office() {
        return $this->hasOne("App\Models\Office");
    }
}


?>