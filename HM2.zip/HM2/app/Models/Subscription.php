<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model {
    protected $fillable = [
        'user_id', 'gym_id', 'price', 'duration', 'date_in', 'date_out'
    ];

    protected $keyType = 'string';

    protected $autoIncrement = false;

    public $timestamps=false;
    
    public function user() {
        return $this->belongsTo('App\Models\User');
    }

    public function gym() {
        return $this->belongsTo('App\Models\Gym');
    }
}

?>