<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class User extends Model {

    protected $fillable = [
        'ID', 'name', 'surname', 'birth', 'age', 'password'
    ];

    protected $autoIncrement = false;

    protected $keyType = 'string';

   /* protected $hidden = [
        'password'
    ];*/

    public $timestamps=false;

  
    public function courses() {
        return $this->belongsToMany(CourseUser::class);
    }

    public function training(){
        return $this->hasOne('App\Models\Training');
    }

    public function comment(){
        return $this->hasMany(('App\Models\Comment'));
    }

    public function subscription() {
        return $this->hasOne("App\Models\Subscription");
    }

}


?>