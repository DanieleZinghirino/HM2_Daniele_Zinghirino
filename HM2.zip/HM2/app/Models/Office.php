<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Office extends Model {
    protected $fillable = [
        'ID', 'gym_id', 'city', 'address', 'director_id'
    ];

    public $timestamps=false;

    public function gym() {
        return $this->belongsTo("App\Models\Gym");
    }

    public function director() {
        return $this->belongsTo('App\Models\Director');
    }
}


?>