<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Training extends Model {
    protected $fillable = [
        'ID', 'pt_id', 'card_id', 'user_id'
    ];
    public $timestamps=false;

    public function PT(){
        return $this->belongsTo('App\Models\Pt');
        
    }

    public function user(){
        return $this->belongsTo('App\Models\User');
    }

    public function card(){
        return $this->belongsTo('App\Models\Card');
    }
}
?>