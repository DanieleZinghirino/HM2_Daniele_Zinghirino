<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CourseUser extends Model {
    protected $table = 'course_user';
    public $timestamps = false;

    protected $fillable = [
        'ID','user_id','course_id'
    ];

    public function courses() {
        return $this->belongsToMany(Course::class);
    }

    public function users() {
        return $this->belongsToMany(User::class);
    }


}
