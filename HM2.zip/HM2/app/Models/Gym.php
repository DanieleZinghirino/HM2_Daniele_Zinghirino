<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gym extends Model {
    protected $fillable = [
        'ID', 'name'
    ];
    public $timestamps=false;

    public function subscription() {
        return $this->hasMany("App\Models\Subscription");
    }

    public function pt() {
        return $this->hasMany('App\Models\PT');
    }

    public function office(){
        return $this->hasMany('App\Models\Office');
    }
}


?>