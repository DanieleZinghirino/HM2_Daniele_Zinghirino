<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homeworw2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Elimina corso</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
            <?php echo csrf_field(); ?>
                <div>
                

                 <div id="corso">
                    <h2> Scegli il corso da eliminare </h2>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <h3><?php echo e($course[0]["name"]); ?></h3>  <input type='radio' name='corso' value='<?php echo e($course[0]["ID"]); ?>'>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                 </div>

                
               </div>

               <div class="submit">
               <?php if($courses): ?>
               <input type='submit' value="Cancella iscrizione dal corso" id="submit">
               <?php endif; ?>

                </div>
                <div><a href="profile">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html><?php /**PATH C:\xampp\htdocs\HM2\resources\views/delete_course.blade.php ENDPATH**/ ?>