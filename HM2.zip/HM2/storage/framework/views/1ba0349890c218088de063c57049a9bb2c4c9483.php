<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo abbonamento</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
        <?php echo csrf_field(); ?>

                <div>
                
                  <div id="abbonamento">
                        <h2> Inserisci il tuo commento </h2>
                        <input type="text" name="recensione"> 
                 </div>

               </div>

               <div class="submit">
                    <input type='submit' value="Invia" id="submit">
                </div>

</form>
            <div><a href="profile">Indietro</a>
            </div>
        </section>
        </main>
    </body>
</html><?php /**PATH C:\xampp\htdocs\HM2\resources\views/add_comment.blade.php ENDPATH**/ ?>