

<?php $__env->startSection('script'); ?>
<script src="script/json_abbonamento.js" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1>Il tuo abbonamento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
<a class="button" href="profile"> Indietro </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HM2\resources\views/data_subscription.blade.php ENDPATH**/ ?>