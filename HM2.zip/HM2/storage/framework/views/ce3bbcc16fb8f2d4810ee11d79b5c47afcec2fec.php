<html>
<meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/profile.css" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('script'); ?>;
<head>
</head>

<body>
     <?php echo $__env->yieldContent('title'); ?>
    
  <div id="dati">
   
    
  </div>
    <?php echo $__env->yieldContent('back'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\HM2\resources\views/layouts/layout.blade.php ENDPATH**/ ?>