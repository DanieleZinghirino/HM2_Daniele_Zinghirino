

<?php $__env->startSection('script'); ?>
<script src="script/dati.js" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1>Dati anagrafici</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
<a class="button" href="profile"> Indietro </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HM2\resources\views/data_user.blade.php ENDPATH**/ ?>