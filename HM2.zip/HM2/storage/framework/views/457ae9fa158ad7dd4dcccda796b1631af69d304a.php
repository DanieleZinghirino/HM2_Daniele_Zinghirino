

<?php $__env->startSection('script'); ?>
<script src="script/json_allenamento.js" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1>Il tuo piano di allenamento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
<a class="button" href="profile"> Indietro </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HM2\resources\views/data_training.blade.php ENDPATH**/ ?>