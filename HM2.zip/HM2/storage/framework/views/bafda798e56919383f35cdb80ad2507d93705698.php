<html>
<head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/course.css" rel="stylesheet" type="text/css">
    <script src="script/jcourses.js" defer></script>
</head>

    <body>
        
            <h1> Scopri i nostri corsi e segna i tuoi preferiti</h1>
        
        
        <div id="allineamento"> <input type="text" id="ricerca"> </div>

        <div id="griglia">


        
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class = "corso" data-nome="<?php echo e($course->name); ?>"> 
            <div class ="stella"> <img src="immagini/stella_vuota.png" /> </div>
            <div> <h2> <?php echo e($course->name); ?> </h2> </div>
            <img src="<?php echo e($course->image); ?>" />
            <p class="descrizione button">Clicca per maggiori informazioni</p>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div id="textP" class="hidden">
            <h1> I tuoi corsi preferiti: </h1>
        </div>

        <div id="preferiti">
        </div>

        <div id="oggi" class="hidden2">
            <h1> I corsi odierni: </h1>
        </div>
        <div id="today">
            
        </div>
    <a id="bottone" href="home"> Indietro </a>
</body>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\HM2\resources\views/courses.blade.php ENDPATH**/ ?>