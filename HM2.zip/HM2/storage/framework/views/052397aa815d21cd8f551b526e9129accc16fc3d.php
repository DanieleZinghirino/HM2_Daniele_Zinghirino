<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo corso</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
            <?php echo csrf_field(); ?>
                <div>
                

                 <div id="corso">
                     <?php for( $i<0; $i<$dim;  $i++): ?>
                        <?php if($numbers[$i]<4): ?>
                        
                            <?php echo e($courses[$i]["name"]); ?>, <?php echo e($courses[$i]["day"]); ?> ore <?php echo e($courses[$i]["time"]); ?>, <?php echo e(4-$numbers[$i]); ?> posti disponibili <input type='radio' name='corso' value = '<?php echo e($courses[$i]["ID"]); ?>'>
                        <?php endif; ?>
                     <?php endfor; ?>
                   
                 </div>

                
               </div>

               <div class="submit">
               <?php if($courses): ?>
               <input type='submit' value='Iscriviti' id='submit'>
               <?php endif; ?>
                  
                </div>
                <div><a href="profile">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html><?php /**PATH C:\xampp\htdocs\HM2\resources\views/add_course.blade.php ENDPATH**/ ?>