

<?php $__env->startSection('script'); ?>
<script src="script/json_istruttori.js" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1>I nostri istruttori</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
<a class="button" href="home"> Indietro </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HM2\resources\views/pts.blade.php ENDPATH**/ ?>