<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">
    <script src="script/verifica_dati_login.js" defer></script>
    </head>

    <body>
        <h1> LOGIN </h1>
      <div id="allineamento">
        
        <form name='credenziali' method ='post' action="<?php echo e(route('login')); ?>">   
        <?php echo csrf_field(); ?>
          
            <div class='codice_fiscale'>
                
                <div><label for='ID'>Codice fiscale</label ></div>
                <div><input type='text' name='ID' value='<?php echo e(old('ID')); ?>'></div>
            </div>
            <div class='password'>
                <div><label for='password'>Password</label></div>
                <div><input type='password' name='password'></div>
            </div>
            <div id="invio">
                 <input type='submit' value="Accedi">
            </div>
        </form>
        <div class="signup">Non hai un account? <a href="register">Iscriviti</a></div>
        <div> <a href="home">Indietro</a></div>
        </div>
        </body>
</html><?php /**PATH C:\xampp\htdocs\HM2\resources\views/login.blade.php ENDPATH**/ ?>