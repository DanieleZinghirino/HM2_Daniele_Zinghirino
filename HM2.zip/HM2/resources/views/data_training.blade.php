@extends('layouts.layout')

@section('script')
<script src="script/json_allenamento.js" defer></script>
@endsection

@section('title')
<h1>Il tuo piano di allenamento</h1>
@endsection

@section('back')
<a class="button" href="profile"> Indietro </a>
@endsection