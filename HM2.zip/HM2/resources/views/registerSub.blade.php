<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo abbonamento</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
            @csrf
                <div>
                
                  <div id="abbonamento">
                        <h2> Scegli la durata del tuo abbonamento </h2>
                        1 mese <input type="radio" name="subscription" value="1"> 
                        3 mesi <input type="radio" name="subscription" value="3"> 
                        6 mesi <input type="radio" name="subscription" value="6"> 
                        12 mesi <input type="radio" name="subscription" value="12"> 
                 </div>

                 <div id="pt">
                    <h2> Scegli il tuo personal trainer </h2>
                   @foreach ($pts as $pt)
                        {{$pt["name"]}} {{$pt["surname"]}} <input type='radio' name='pt' value='{{$pt["ID"]}}'>
                   @endforeach
                 </div>

                 <div id="scheda">
                    <h2> Scegli la tua tipologia di allenamento </h2>
                    @foreach ($cards as $card)
                        {{$card["type"]}}, {{$card["duration"]}} mesi, livello di difficoltà = {{$card["difficulty"]}} <input type='radio' name='card' value='{{$card["ID"]}}'>
                    @endforeach
                 </div>
               </div>

               <div class="submit">
                    <input type='submit' value="Invia" id="submit">
                </div>

            </form>
            <div class="signup">Hai un account? <a href="login">Accedi</a>
            </div>
        </section>
        </main>
    </body>
</html>