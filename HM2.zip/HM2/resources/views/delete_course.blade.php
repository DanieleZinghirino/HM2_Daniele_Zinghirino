<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homeworw2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Elimina corso</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
            @csrf
                <div>
                

                 <div id="corso">
                    <h2> Scegli il corso da eliminare </h2>
                    @foreach($courses as $course) 
                    <h3>{{$course[0]["name"]}}</h3>  <input type='radio' name='corso' value='{{$course[0]["ID"]}}'>
                   
                    @endforeach
                    
                 </div>

                
               </div>

               <div class="submit">
               @if($courses)
               <input type='submit' value="Cancella iscrizione dal corso" id="submit">
               @endif

                </div>
                <div><a href="profile">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html>