<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">

        <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Scegli il tuo personal trainer</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post'>
            @csrf
                <div>
                

                 <div id="pt">
                    
                 @foreach ($pts as $pt)


                 @if($pt->ID!== $pt_user)
                     {{$pt["name"]}}  {{$pt["surname"]}} <input type='radio' name='pt' value='{{$pt["ID"]}}'>
                 @endif
                
                       
                 @endforeach
                 </div>

                
               </div>

               <div class="submit">
                    <input type='submit' value="Conferma" id="submit">
                </div>

                <div><a href="profile">Indietro</a>
            </div>

            </form>
        </section>
        </main>
    </body>
</html>