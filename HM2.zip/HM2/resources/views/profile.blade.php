<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/profile.css" rel="stylesheet" type="text/css">

    </head>

    <body>
       
      <section>
        <div id="top">
          
          <div> 
            <a class="button" href='home'>Home</a> 
          </div>
         <div> <h1> PROFILO </h1> 
          </div>
          <div>         
        <a class="button" href='logout'>Esci</a>
          
        </div>
       </div>
      
        <div id="blocco"> 
          <div> <a href="data"> I tuoi dati </a> </div>
          <div> <a href="subscription"> Il tuo abbonamento </a> </div>
          <div> <a href="training"> Il tuo piano di allenamento </a> </div>
          <div> <a href="pt"> Il tuo personal trainer </a> </div>
          <div> <a href="course"> I tuoi corsi </a> </div>     
          <div> <a href="comment"> Lascia una recensione </a> </div>
  
          </div>
        </section>
    </body>
</html>