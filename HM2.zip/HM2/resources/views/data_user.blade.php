@extends('layouts.layout')

@section('script')
<script src="script/dati.js" defer></script>
@endsection

@section('title')
<h1>Dati anagrafici</h1>
@endsection

@section('back')
<a class="button" href="profile"> Indietro </a>
@endsection