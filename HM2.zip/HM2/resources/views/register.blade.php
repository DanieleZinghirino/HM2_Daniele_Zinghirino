<html>
    <head>
    <meta charset="utf-8">
    <title>Daniele Zinghirino: Homework2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <link href="css/form.css" rel="stylesheet" type="text/css">
    <script src="script/verifica_dati_iscrizione.js" defer></script>

    <title>Iscriviti</title>
    </head>
    <body>
        <main>
        <section>
            <h1>Iscriviti</h1>
            <div id="allineamento">
            <form name='iscrizione' method='post' action="{{ route('register') }}">
            @csrf
                <div class="names">
                    <div class="nome">
                        <div><label for='name'>Nome</label></div>
                            <div><input type='text' name='name'  value='{{ old('name') }}'></div>
                        

                    </div>
                    <div class="cognome">
                        <div><label for='surname'>Cognome</label></div>
                        <div><input type='text' name='surname'  value='{{ old('surname') }}'></div>

                    </div>
                </div>
                <div class="codice_fiscale">
                    <div><label for='ID'>Codice fiscale</label></div>
                    <div><input type='text' name='ID' value='{{ old('ID') }}'></div>

                </div>
                <div class="giorno_nascita">
                    <div><label for='giorno_nascita'>Giorno di nascita</label></div>
                    <div><input type='number' name='giorno_nascita' min="1" max="31" value='{{ old('giorno_nascita') }}'></div>
                </div>
                <div class="mese_nascita">
                    <div><label for='mese_nascita'>Mese di nascita</label></div>
                    <div><input type='number' name='mese_nascita' min="1" max="12" value='{{ old('mese_nascita') }}'></div>
                </div> 
                <div class="anno_nascita">
                    <div><label for='anno_nascita'>Anno di nascita</label></div>
                    <div><input type='number' name='anno_nascita' min="1931" max="2008" value='{{ old('anno_nascita') }}'></div>
                </div>
                <div class="password">
                    <div><label for='password'>Password</label></div>
                    <div><input type='password' name='password'></div>
                    

                </div>
                <div class="confirm_password">
                    <div><label for='confirm_password'>Conferma Password</label></div>
                    <div><input type='password' name='confirm_password'></div>

                </div>
                <div class="submit">
                    <input type='submit' value="Registrati" id="submit">
                </div>
            </form>
            <div class="signup">Hai un account? <a href="login">Accedi</a>
            </div>
            <div><a href="home">Indietro</a>
            </div>
        </section>
        </main>
    </body>
</html>