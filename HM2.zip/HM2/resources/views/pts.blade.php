@extends('layouts.layout')

@section('script')
<script src="script/json_istruttori.js" defer></script>
@endsection

@section('title')
<h1>I nostri istruttori</h1>
@endsection

@section('back')
<a class="button" href="home"> Indietro </a>
@endsection