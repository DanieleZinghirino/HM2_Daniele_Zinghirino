@extends('layouts.layout')

@section('script')
<script src="script/json_corsi.js" defer></script>
@endsection

@section('title')
<h1>I tuoi corsi</h1>
@endsection

@section('back')
<a class="button" href="profile"> Indietro </a>
@endsection