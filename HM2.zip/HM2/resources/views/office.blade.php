@extends('layouts.layout')

@section('script')
<script src="script/json_sedi.js" defer></script>
@endsection

@section('title')
<h1>Le nostre sedi</h1>
@endsection

@section('back')
<a class="button" href="home"> Indietro </a>
@endsection