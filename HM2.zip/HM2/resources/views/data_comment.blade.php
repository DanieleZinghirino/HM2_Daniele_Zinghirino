@extends('layouts.layout')

@section('script')
<script src="script/json_comments.js" defer></script>
@endsection

@section('title')
<h1>Recensioni</h1>
@endsection

@section('back')
<a class="button" href="home"> Indietro </a>
@endsection