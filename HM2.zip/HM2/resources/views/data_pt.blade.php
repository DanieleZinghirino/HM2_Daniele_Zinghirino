@extends('layouts.layout')

@section('script')
<script src="script/json_pt.js" defer></script>
@endsection

@section('title')
<h1>Il tuo istruttore</h1>
@endsection

@section('back')
<a class="button" href="profile"> Indietro </a>
@endsection