<?php
namespace App\Models;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

#HOMECONTROLLER
Route::get('/home', 'HomeController@home')->name('home');
Route::get('/profile', 'HomeController@profile')->name('profile');
Route::get('/data', 'HomeController@data')->name('data');
Route::get('/courses', 'HomeController@courses')->name('courses');
Route::get('/subscription',  'HomeController@subscription')->name('subscription');
Route::get('/training',  'HomeController@training')->name('training');
Route::get('/pt',  'HomeController@pt')->name('pt');
Route::get('/course',  'HomeController@course')->name('course');
Route::get('/comment',  'HomeController@comment')->name('comment');
Route::get('/office',  'HomeController@office')->name('office');
Route::get('/pts',  'HomeController@pts')->name('pts');
Route::get('/exercise',  'HomeController@exercise')->name('exercise');
Route::get('/timetables',  'HomeController@timetables')->name('timetables');
#LOGINCONTROLLER
Route::get('/login', 'LoginController@login')->name('login');
Route::post('login', 'LoginController@postLogin')->name('checkLogin');
Route::get('logout', 'LoginController@logout')->name('logout');
#REGISTERCONTROLLER
Route::get('/register', 'RegisterController@index')->name('register');
Route::post('/register', 'RegisterController@register')->name('registerCreate');
Route::get('/registerSub', 'RegisterController@registerSub')->name('registerSub');
Route::post('/registerSub', 'RegisterController@registerSubPost')->name('registerSubPost');
Route::get('/addComment', 'RegisterController@addComment')->name('addComment');
Route::post('/addComment', 'RegisterController@addCommentPost')->name('addCommentPost');
Route::get('/changePt', 'RegisterController@changePt')->name('changePt');
Route::post('/changePt', 'RegisterController@changePtPost')->name('changePtPost');
Route::get('/deleteCourse',  'RegisterController@deleteCourse')->name('deleteCourse');
Route::post('/deleteCourse',  'RegisterController@deleteCoursePost')->name('deleteCoursePost');
Route::get('/addCourse',  'RegisterController@addCourse')->name('addCourse');
Route::post('/addCourse',  'RegisterController@addCoursePost')->name('addCoursePost');
#FETCHCONTROLLER
Route::get('/fetchData', 'FetchController@fetchData')->name('fetchData');
Route::get('/fetchSubscription', 'FetchController@fetchSubscription')->name('fetchSubscription');
Route::get('/fetchTraining', 'FetchController@fetchTraining')->name('fetchTraining');
Route::get('/fetchPt', 'FetchController@fetchPt')->name('fetchPt');
Route::get('/fetchCourse', 'FetchController@fetchCourse')->name('fetchCourse');
Route::get('/fetchComment', 'FetchController@fetchComment')->name('fetchComment');
Route::get('/fetchCourses', 'FetchController@fetchCourses')->name('fetchCourses');
Route::get('/fetchOffice', 'FetchController@fetchOffice')->name('fetchOffice');
Route::get('/fetchPts', 'FetchController@fetchPts')->name('fetchPts');
Route::get('/fetchTimetables', 'FetchController@fetchTimetables')->name('fetchTimetables');
