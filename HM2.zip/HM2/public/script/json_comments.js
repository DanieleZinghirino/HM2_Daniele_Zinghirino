function fetch_recensioni_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';
    if (json.length) {
        for (var i = 0; i < json.length; i++) {
            var elemento = json[i];
            console.log(elemento);
            let x;
            x = document.createElement("span");
            x.textContent = '"' + elemento.text + '"';

            x.classList.add("titolo");
            elenco.appendChild(x);

            x = document.createElement("span");
            x.textContent = elemento.name + " " + elemento.surname;
            x.classList.add("dato");
            elenco.appendChild(x);

            x = document.createElement("span");
            x.textContent = "Data:" + elemento.day +
                ", ore: " + elemento.time;
            elenco.appendChild(x);

            let spazio = document.createElement("br");
            x.appendChild(spazio);
            let spazio2 = document.createElement("br");
            x.appendChild(spazio2);
        }
    } else {
        let x;

        x = document.createElement("span");
        x.textContent = "Nessuna recensione";
        x.classList.add("dato");
        elenco.appendChild(x);
    }

    let bottone = document.createElement("a");
    bottone.textContent = "Aggiungi recensione";
    bottone.classList.add("button");
    bottone.href = "addComment";

    elenco.appendChild(bottone);
}

function fetchResponse(response) {
    return response.json();
}

function fetch_recensioni() {

    fetch("fetchComment").then(fetchResponse).then(fetch_recensioni_json);
}

fetch_recensioni();