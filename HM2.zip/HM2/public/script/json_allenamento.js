function fetch_allenamento_json(json) {
    const elenco = document.getElementById("dati");
    var elemento = json;
    console.log(elemento);

    elenco.innerHTML = '';
    let x;

    x = document.createElement("span");
    x.textContent = "Tipologia allenamento = " + elemento.type;
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Durata = " + elemento.duration + " mesi";
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Indice di difficoltà = " + elemento.difficulty;
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Nome Istruttore = " + elemento.pt_name + " " + elemento.pt_surname;
    x.classList.add("dato");
    elenco.appendChild(x);
}

function fetchResponse(response) {
    return response.json();
}

function fetch_allenamento() {

    fetch("fetchTraining").then(fetchResponse).then(fetch_allenamento_json);
}

fetch_allenamento();