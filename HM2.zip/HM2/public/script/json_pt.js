function fetch_pt_json(json) {
    const elenco = document.getElementById("dati");
    var elemento = json;
    console.log(elemento);

    elenco.innerHTML = '';
    let x;

    x = document.createElement("span");
    x.textContent = "Nome = " + elemento.name;
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Cognome = " + elemento.surname;
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Data di nascita = " + elemento.birth;
    x.classList.add("dato");
    elenco.appendChild(x);

    x = document.createElement("span");
    x.textContent = "Numero di matricola = " + elemento.ID;
    x.classList.add("dato");
    elenco.appendChild(x);

    let bottone = document.createElement("a");
    bottone.textContent = "Cambia personal trainer";
    bottone.classList.add("button");
    bottone.href = "changePt";

    elenco.appendChild(bottone);
}

function fetchResponse(response) {
    return response.json();
}

function fetch_pt() {

    fetch("fetchPt").then(fetchResponse).then(fetch_pt_json);
}

fetch_pt();