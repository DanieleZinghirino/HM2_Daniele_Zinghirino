const form = document.forms['iscrizione'];
form.addEventListener('submit', verifica);

function verifica(event) {
    if (form.name.value.length == 0 &&
        form.surname.value.length == 0 &&
        form.ID.value.length == 0 &&
        form.giorno_nascita.value.length == 0 &&
        form.mese_nascita.value.length == 0 &&
        form.anno_nascita.value.length == 0 &&
        form.password.value.length == 0 &&
        form.confirm_password.value.length == 0) {
        alert("Inserisci i dati!");
        event.preventDefault();
    } else {
        if (form.name.value.length == 0) {
            alert("Inserisci il tuo nome!");
            event.preventDefault();
        } else {
            if (form.surname.value.length == 0) {
                alert("Inserisci il tuo cognome!");
                event.preventDefault();
            } else {
                if (form.ID.value.length == 0) {
                    alert("Inserisci il tuo codice fiscale!");
                    event.preventDefault();
                } else {
                    if (form.giorno_nascita.value.length == 0 ||
                        form.mese_nascita.value.length == 0 ||
                        form.anno_nascita.value.length == 0) {
                        alert("Inserisci la tua data di nascita!");
                        event.preventDefault();
                    } else {
                        if (form.password.value.length == 0) {
                            alert("Inserisci la password!");
                            event.preventDefault();
                        } else {
                            if (form.confirm_password.value.length == 0) {
                                alert("Conferma la password!");
                                event.preventDefault();
                            } else {
                                if (form.password.value != form.confirm_password.value) {
                                    alert("Inserisci la stessa password!");
                                    event.preventDefault();
                                } else {
                                    if (form.password.value.length < 8) {
                                        alert("Password troppo breve!\nInserisci almeno 8 caratteri");
                                        event.preventDefault();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}