const stellaList = document.querySelectorAll(".stella");
for (let stella of stellaList)
    stella.addEventListener("click", aggiungiPreferito);


let conta = 0;
let conta2 = 0;

const descr = document.querySelectorAll(".descrizione");
for (d of descr)
    d.addEventListener("click", estendiDescrizione);

let input = document.querySelector("#ricerca");
input.addEventListener("input", ricercaCorso);

function jsonDescrizione(json) {
    let esteso = document.querySelector(".Esteso");
    let nome_corso = esteso.dataset.nome;
    let descrivi = document.querySelector(".Descrivi");

    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];
        if (elemento.name == nome_corso) {
            descrivi.textContent = elemento.description;
        }
    }
    esteso.classList.remove("Esteso");
    descrivi.classList.remove("Descrivi");

}

function jsonPreferiti(json) {

    let box = document.getElementById('preferiti');

    let new_corso = document.createElement('div');
    new_corso.classList.add('corso');
    new_corso.classList.add('selezionato');
    box.appendChild(new_corso);

    const corso = document.querySelector('.selezionato');

    let cliccato = document.querySelector(".Cliccato");
    let nome_corso = cliccato.dataset.nome;

    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];

        if (elemento.name == nome_corso) {
            var div_titolo = document.createElement('h2');
            var div_pic = document.createElement('img');

            div_titolo.textContent = elemento.name;
            div_pic.src = elemento.image;

            corso.appendChild(div_titolo);
            corso.appendChild(div_pic);
            conta++;
            if (conta == 1)
                document.querySelector('#textP').classList.remove('hidden');

            new_corso.classList.remove('selezionato');
            corso.setAttribute("nome", nome_corso);
        }
    }
    cliccato.classList.remove("Cliccato");

}

function risposta(response) {
    return response.json();
}

function aggiungiPreferito() {
    const padreStella = event.currentTarget.parentNode;
    padreStella.classList.add("Cliccato");


    event.currentTarget.querySelector("img").src = "immagini/stella_piena.png";
    event.currentTarget.removeEventListener("click", aggiungiPreferito);
    event.currentTarget.addEventListener("click", rimuoviPreferito);

    fetch("fetchCourses").then(risposta).then(jsonPreferiti);

}


function rimuoviPreferito() {
    const padre = event.currentTarget.parentNode;
    const n_corso = padre.dataset.nome;

    event.currentTarget.querySelector("img").src = "immagini/stella_vuota.png";
    event.currentTarget.addEventListener("click", aggiungiPreferito);
    event.currentTarget.removeEventListener("click", rimuoviPreferito);

    let listaCorsi = document.querySelectorAll('#preferiti .corso');

    for (let corsi of listaCorsi) {
        if (n_corso == corsi.getAttribute("nome")) {
            document.getElementById('preferiti').removeChild(corsi);
            conta--;
        }
        if (!conta)
            document.querySelector('#textP').classList.add('hidden');
    }
}

function estendiDescrizione() {
    event.currentTarget.classList.add("Descrivi");
    event.currentTarget.parentNode.classList.add("Esteso");
    //const titolo_corso = event.currentTarget.parentNode.dataset.nome;
    fetch("fetchCourses").then(risposta).then(jsonDescrizione);
    //event.currentTarget.textContent = COSTANTI[titolo_corso].descrizione;
    event.currentTarget.classList.remove("button");
    event.currentTarget.addEventListener("click", comprimiDescrizione);
    event.currentTarget.removeEventListener("click", estendiDescrizione);
}

function comprimiDescrizione() {
    const titolo_corso = event.currentTarget.parentNode.dataset.nome;
    event.currentTarget.textContent = "Clicca per maggiori informazioni";
    event.currentTarget.classList.add("button");
    event.currentTarget.removeEventListener("click", comprimiDescrizione);
    event.currentTarget.addEventListener("click", estendiDescrizione);
}

function ricercaCorso() {
    let testo_minuscolo = document.getElementById("ricerca").value;
    let testo = testo_minuscolo.toUpperCase();
    let corsiList = document.querySelectorAll(".corso");
    console.log("La dimensione della lista di corsi è ----> " + corsiList.length);

    for (let i = 0; i < corsiList.length; i++) {
        if (corsiList[i].dataset.nome.indexOf(testo) === -1) {
            corsiList[i].classList.add('hidden');
        } else
        if (corsiList[i].classList.contains('hidden'))
            corsiList[i].classList.remove('hidden');
    }
}

fetch("fetchCourses").then(risposta).then(jsonToday);

function jsonToday(json) {
    console.log(json);
    const data = new Date();
    var day = data.getDay();
    var giorno;
    if (day == 0)
        giorno = "Domenica";
    if (day == 1)
        giorno = "Lunedi";
    if (day == 2)
        giorno = "Martedi";
    if (day == 3)
        giorno = "Mercoledi";
    if (day == 4)
        giorno = "Giovedi";
    if (day == 5)
        giorno = "Venerdi";
    if (day == 5)
        giorno = "Sabato";

    var box = document.getElementById('today');

    console.log(json);
    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];

        if (elemento.day == giorno) {
            let corso = document.createElement('div');
            corso.classList.add('corso');

            var div_titolo = document.createElement('h2');
            var div_pic = document.createElement('img');
            var orario = document.createElement('h2');

            div_titolo.textContent = elemento.name;
            div_pic.src = elemento.image;
            orario.textContent = "Ore " + elemento.time;

            corso.appendChild(div_titolo);
            corso.appendChild(div_pic);
            corso.appendChild(orario);

            box.appendChild(corso);
            conta2++;
            if (conta2 == 1)
                document.querySelector('#oggi').classList.remove('hidden2');
        }
    }
}