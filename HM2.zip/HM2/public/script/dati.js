function fetch_dati_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';

    for (let dato in json) {
        console.log(json[0]);
    }

    let x = document.createElement("span");
    x.textContent = "Nome = " + json.name;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Cognome = " + json.surname;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Codice fiscale = " + json.ID;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Data di nascita = " + json.birth;
    x.classList.add("dato");
    elenco.appendChild(x);
    x = document.createElement("span");
    x.textContent = "Età = " + json.age + " anni";
    x.classList.add("dato");
    elenco.appendChild(x);

}

function fetchResponse(response) {
    return response.json();
}

function fetch_dati_anagrafici() {
    //const profile = document.body.dataset.user ? "?user="+document.body.dataset.user : "";

    fetch("fetchData").then(fetchResponse).then(fetch_dati_json);
}

fetch_dati_anagrafici();