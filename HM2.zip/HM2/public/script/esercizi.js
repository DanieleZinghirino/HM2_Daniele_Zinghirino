let casellaList = document.querySelectorAll(".casella");
for (let casella of casellaList)
    casella.addEventListener("click", selezionaMuscolo);

function selezionaMuscolo() {

    if (event.currentTarget.classList.contains("muscolo_selezionato")) {
        event.currentTarget.querySelector("img").src = "immagini/casella_vuota.png";
        event.currentTarget.classList.remove("muscolo_selezionato");
        const api = document.querySelector('#api');
        api.innerHTML = '';
        api.classList.remove("colore");
    } else {
        let caselle = document.querySelectorAll(".casella");
        for (let casella of caselle)
            if (casella.classList.contains("muscolo_selezionato")) {
                casella.classList.remove("muscolo_selezionato");
                casella.querySelector("img").src = "immagini/casella_vuota.png";
            }

        event.currentTarget.classList.add("muscolo_selezionato");
        event.currentTarget.querySelector("img").src = "immagini/casella_piena.png";

        let padre_muscolo = event.currentTarget.parentNode;
        let nome_muscolo = padre_muscolo.dataset.nome;

        let id_muscolo = ASSOCIAZIONI[nome_muscolo];

        let url_esercizi = 'https://wger.de/api/v2/exercise/?muscles=' + id_muscolo + '&language=2';

        fetch(url_esercizi).then(onResponse).then(onJson);
    }
}

function onResponse(response) {
    return response.json();
}

function onJson(json) {
    const api = document.querySelector('#api');
    api.innerHTML = '';
    const intro = document.createElement("h2");
    intro.textContent = "I nostri esercizi consigliati: ";
    api.appendChild(intro);
    let risultati = json.count;
    if (risultati > 8)
        risultati = 8;

    for (let i = 0; i < risultati; i++) {
        let risultato = json.results[i];
        let nome_esercizio = risultato.name;
        var contenitore = document.createElement('div');
        var titolo = document.createElement('div');
        titolo.textContent = nome_esercizio;
        contenitore.appendChild(titolo);
        api.appendChild(contenitore);
        api.classList.add("colore");
    }
}

const ASSOCIAZIONI = {
    'petto': 4,
    'braccia': 1,
    'schiena': 12,
    'polpacci': 7,
    'gambe': 10,
    'glutei': 8,
    'spalle': 2,
    'addominali': 6
};