function fetch_allenamento_json(json) {
    const elenco = document.getElementById("dati");
    for (var i = 0; i < json.length; i++) {
        var elemento = json[i];
        console.log(elemento);

        elenco.innerHTML = '';
        let x;

        x = document.createElement("span");
        x.textContent = "Tipologia allenamento = " + elemento.Tipologia;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Durata = " + elemento.Durata_Scheda + " mesi";
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Indice di difficoltà = " + elemento.Difficoltà;
        x.classList.add("dato");
        elenco.appendChild(x);

        x = document.createElement("span");
        x.textContent = "Nome Istruttore = " + elemento.Nome_Istruttore + " " + elemento.Cognome_Istruttore;
        x.classList.add("dato");
        elenco.appendChild(x);
    }

}

function fetchResponse(response) {
    return response.json();
}

function fetch_allenamento() {

    fetch("fetch_dati.php").then(fetchResponse).then(fetch_allenamento_json);
}

fetch_allenamento();