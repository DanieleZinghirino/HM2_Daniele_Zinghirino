function fetch_abbonamento_json(json) {
    const elenco = document.getElementById("dati");
    console.log(json.length);
    if (json.length > 0) {
        var elemento = json;
        console.log(elemento);

        elenco.innerHTML = '';

        let x;

        let oggi = new Date();
        let scadenza = new Date(elemento.Data_Scadenza);
        let diff = scadenza.getTime() - oggi.getTime();

        //Se la data preimpostata è già passata     
        if (diff > 0) {
            x = document.createElement("span");
            x.textContent = "Codice abbonamento = " + elemento.ID;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Prezzo = " + elemento.price + "€";
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Durata = " + elemento.duration + " mesi";
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Data di iscrizione = " + elemento.date_in;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Data di scandenza abbonamento = " + elemento.date_out;
            x.classList.add("dato");
            elenco.appendChild(x);
        } else { //evento passato 
            x = document.createElement("span");
            x.textContent = "Abbonamento non attivo!";
            x.classList.add("dato");
            let bottone = document.createElement("a");
            bottone.textContent = "Rinnova abbonamento";
            bottone.classList.add("button");
            bottone.href = "iscrizione_abbonamento.php";
            elenco.appendChild(x);
            elenco.appendChild(bottone);
        }

    } else {
        let bottone = document.createElement("a");
        bottone.textContent = "Scegli il tuo abbonamento";
        bottone.classList.add("button");
        bottone.href = "registerSub";
        elenco.appendChild(bottone);
    }
}

function fetchResponse(response) {
    return response.json();
}

function fetch_abbonamento() {

    fetch("fetchSubscription").then(fetchResponse).then(fetch_abbonamento_json);
}

fetch_abbonamento();