let ora = document.querySelector("button");
ora.addEventListener("click", verificaData);

function verificaData() {

    fetch("fetchTimetables").then(risposta).then(json_orario);

}

function risposta(response) {
    return response.json();
}

function json_orario(json) {
    var padre_bottone = document.querySelector(".orario");
    padre_bottone.classList.add("hidden");
    var sostituto_bottone = document.createElement("h2");
    const data = new Date();
    var day = data.getDay();

    /*console.log(day);
    console.log(json);*/

    if (json.ok) {
        sostituto_bottone.textContent = "Oggi la palestra rimarrà chiusa essendo un giorno festivo!";

    } else {
        if (day === 6) sostituto_bottone.textContent = "Oggi la palestra è aperta dalle 10:00 alle 16:00!";
        if (day === 0) sostituto_bottone.textContent = "Oggi la palestra rimarrà chiusa essendo Domenica!";
        if (day < 6 && day > 0) sostituto_bottone.textContent = "Oggi la palestra è aperta dalle 08:00 alle 22:00!";
    }

    var padre = padre_bottone.parentNode;
    padre.appendChild(sostituto_bottone);
}