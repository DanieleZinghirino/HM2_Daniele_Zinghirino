function fetch_corsi_json(json) {
    const elenco = document.getElementById("dati");
    elenco.innerHTML = '';
    if (json.length) {
        for (var i = 0; i < json.length; i++) {
            var elemento = json[i];
            console.log(elemento);

            let x;

            x = document.createElement("span");
            x.textContent = "Corso #" + elemento.ID;
            x.classList.add("titolo");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Nome = " + elemento.name;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Giorno = " + elemento.day;
            x.classList.add("dato");
            elenco.appendChild(x);
            x = document.createElement("span");
            x.textContent = "Orario = " + elemento.time;
            x.classList.add("dato");
            elenco.appendChild(x);


        }
        let bottone = document.createElement("a");
        bottone.textContent = "Elimina corso";
        bottone.classList.add("button");
        bottone.href = "deleteCourse";

        elenco.appendChild(bottone);
    } else {
        let x;

        x = document.createElement("span");
        x.textContent = "Non sei iscritto a nessun corso!";
        x.classList.add("dato");
        elenco.appendChild(x);


    }
    let bottone = document.createElement("a");
    bottone.textContent = "Iscriviti ad un corso";
    bottone.classList.add("button");
    bottone.href = "addCourse";

    elenco.appendChild(bottone);
}

function fetchResponse(response) {
    return response.json();
}

function fetch_abbonamento() {

    fetch("fetchCourse").then(fetchResponse).then(fetch_corsi_json);
}

fetch_abbonamento();