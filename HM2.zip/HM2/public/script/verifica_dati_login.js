const form = document.forms['credenziali'];
form.addEventListener('submit', verifica);

function verifica(event) {
    if (form.ID.value.length == 0 &&
        form.password.value.length == 0) {
        alert("Inserisci tutte le credenziali!");
        event.preventDefault();
    } else {
        if (form.ID.value.length == 0) {
            alert("Inserisci il tuo codice fiscale!");
            event.preventDefault();
        }
        if (form.password.value.length == 0) {
            alert("Inserisci la password!");
            event.preventDefault();
        }

    }
}